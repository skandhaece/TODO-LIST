import express from "express"
import pg from "pg"
import axios from "axios"
import bodyParser from "body-parser"


const port = 3000;
const app = express();
app.use(bodyParser.urlencoded({extended : true}));
app.use(express.static("public"));

const db = new pg.Client({
    database:"todolist_database",
    host:"localhost",
    user:"postgres",
    password:"Espre550123$",
    port:5432
});
db.connect();

async function getAllTasks(){
    const result = await db.query("SELECT * FROM public.todolist ORDER BY is_done ASC");
    return result.rows;
}


async function deleteData(task_id){
    const result = await db.query("DELETE FROM public.todolist WHERE task_id = $1",[task_id])
}


async function addNewTask(newTaskName) {
    const result = await db.query("INSERT INTO public.todolist(task_name) VALUES($1)",[newTaskName]);
}

async function toCheck(task_id) {
    const result = await db.query("UPDATE public.todolist SET is_done = true WHERE task_id = $1",[task_id]);
}

async function toUncheck(task_id) {
    const result = await db.query("UPDATE public.todolist SET is_done = false WHERE task_id = $1",[task_id]);
}


app.get("/",async (req, res)=>{
    const tasks = await getAllTasks();
    console.log(typeof(tasks[0].is_done))
    console.log(tasks)
    res.render("index.ejs",
        {
            tasks:tasks
        }
    );

});


app.get("/remove/:id",async (req, res)=>{
    const idToRemove = req.params.id;
    const removedTask = await deleteData(idToRemove);
    console.log(removedTask)
    console.log("TASK removed");
    res.redirect("/");
})

app.post("/addTask", async(req, res)=>{
    const newTaskName = req.body.newTask;
    console.log(newTaskName)
   const addedTask =  await addNewTask(newTaskName);
   console.log(addedTask)
   console.log("NEW task added")
    res.redirect("/");
})

app.get("/uncheck/:id", async(req, res)=>{
    const idtoUncheck = req.params.id;
    await toUncheck(idtoUncheck);   
    res.redirect("/")
});

app.get("/check/:id", async(req, res)=>{
    const idToCheck = req.params.id;
    await toCheck(idToCheck);
    res.redirect("/")
});

app.listen(port, ()=>{
    console.log(`SERVER RUNNING AT http://localhost:${port}/`);
})
