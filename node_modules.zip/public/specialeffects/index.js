// document.querySelector(".newTask input").addEventListener("input", ()=>{
//     this.style.fontFamily = "Open Sans";
// })